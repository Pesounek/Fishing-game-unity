using UnityEngine;
using UnityEngine.AI; 

public class MonsterAI : MonoBehaviour
{
    public enum MonsterState { Dormant, Stalking, Hunting }
    
    [Header("Aktuální stav")]
    public MonsterState currentState = MonsterState.Dormant;

    [Header("Reference")]
    public Transform player; 
    private NavMeshAgent agent; 

    [Header("Nastavení pohybu")]
    public float stalkingSpeed = 2f; 
    public float huntingSpeed = 5.5f;  
    public float stalkingDistance = 15f; 

    // --- NOVÉ: Spouštěče (Triggery) ---
    [Header("Spouštěče Vzdálenosti")]
    public float wakeUpRadius = 40f; // Na kolik metrů se probudí a začne Stalkovat
    public float huntingRadius = 10f; // Na kolik metrů se naštve a začne Lovit

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();

        if (player == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null) player = playerObj.transform;
        }
    }

    void Update()
    {
        if (player == null) return;

        // Neustále si měříme vzdálenost k hráči
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        switch (currentState)
        {
            case MonsterState.Dormant:
                agent.isStopped = true;

                // LOGIKA PROBUZENÍ: Pokud hráč vleze do 40 metrů, začneme Stalkovat!
                if (distanceToPlayer <= wakeUpRadius)
                {
                    ChangeState(MonsterState.Stalking);
                }
                break;

            case MonsterState.Stalking:
                agent.isStopped = false;
                agent.speed = stalkingSpeed;
                
                // LOGIKA ÚTOKU: Pokud je hráč až moc drzý a přijde na 10 metrů, Lovíme!
                if (distanceToPlayer <= huntingRadius)
                {
                    ChangeState(MonsterState.Hunting);
                    break; // Ukončíme tenhle blok, ať to hned přeskočí do lovu
                }

                // Jinak si klasicky držíme bezpečný odstup
                if (distanceToPlayer > stalkingDistance)
                {
                    agent.SetDestination(player.position);
                }
                else
                {
                    agent.SetDestination(transform.position); 
                }
                break;

            case MonsterState.Hunting:
                agent.isStopped = false;
                agent.speed = huntingSpeed;
                agent.SetDestination(player.position);
                
                
                 if (distanceToPlayer > 50f) ChangeState(MonsterState.Stalking);
                break;
        }
    }

    public void ChangeState(MonsterState newState)
    {
        currentState = newState;
        Debug.Log("Monstrum změnilo stav na: " + newState.ToString());
    }

    private void OnTriggerEnter(Collider other)
    {
        if (currentState == MonsterState.Hunting && other.CompareTag("Player"))
        {
            TimeManager tm = FindObjectOfType<TimeManager>();
            if (tm != null)
            {
                tm.TriggerGameOver();
            }
        }
    }
}