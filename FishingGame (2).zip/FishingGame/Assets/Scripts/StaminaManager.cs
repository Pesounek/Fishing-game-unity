using UnityEngine;
using UnityEngine.UI;

public class StaminaManager : MonoBehaviour
{
    [Header("Parametry Staminy")]
    public float maxStamina = 100f;
    public float currentStamina;
    public float drainRate = 25f; 
    public float regenRate = 15f; 

    [Header("Zpoždění obnovy (Delay)")]
    public float regenDelay = 1.5f; // Doba v sekundách, než postava popadne dech
    private float regenTimer = 0f;

    [Header("UI Reference")]
    public Slider staminaBar; 
    public Image staminaFillImage; // Odkaz na samotnou barvu lišty

    [Header("Barvy Lišty")]
    public Gradient staminaColorGradient; // Plynulý přechod od červené do zelené

    [Header("Stav")]
    public bool isSprinting = false;
    public bool canSprint = true;

    void Start()
    {
        currentStamina = maxStamina;
        if (staminaBar != null)
        {
            staminaBar.maxValue = maxStamina;
            staminaBar.value = currentStamina;
        }
    }

    void Update()
    {
        // 1. Zpracování úbytku při běhu
        if (isSprinting && currentStamina > 0)
        {
            currentStamina -= drainRate * Time.deltaTime;
            regenTimer = 0f; // Vynulujeme časovač odpočinku, protože právě běžíme!

            if (currentStamina <= 0)
            {
                currentStamina = 0;
                canSprint = false;
                isSprinting = false;
            }
        }
        // 2. Zpracování ZPOŽDĚNÍ a obnovy (Když jdeme krokem nebo stojíme)
        else if (!isSprinting && currentStamina < maxStamina)
        {
            regenTimer += Time.deltaTime; // Odpočítáváme čas oddechu

            // Začneme staminu doplňovat AŽ když uběhne nastavený čas (regenDelay)
            if (regenTimer >= regenDelay)
            {
                currentStamina += regenRate * Time.deltaTime;

                if (currentStamina > (maxStamina * 0.2f))
                {
                    canSprint = true;
                }
            }
        }

        // 3. Aktualizace UI a BAREV
        if (staminaBar != null)
        {
            staminaBar.value = currentStamina;
            
            // Změna barvy podle procent (0.0 až 1.0)
            if (staminaFillImage != null)
            {
                float staminaPercent = currentStamina / maxStamina;
                staminaFillImage.color = staminaColorGradient.Evaluate(staminaPercent);
            }
        }
    }
}