using UnityEngine;
using UnityEngine.UI;
using TMPro; 

public class ShopManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject shopPanel; 
    public GameObject interactText; 

    [Header("Reference")]
    public InventoryManager inventory; 
    public FishingController fishingController;

    [Header("Prodej")]
    public float pricePerKg = 15f;

    [Header("Upgrady")]
    public float upgradeCost = 150f;
    public float newBagCapacity = 30f; 

    public float rodUpgradeCost = 250f;

    public float flashlightUpgradeCost = 200f;
    public Light playerFlashlight; 
    public float newFlashlightRange = 150f; 
    public float newFlashlightIntensity = 1000f; 

    [Header("Tlačítka")]
    public Button btnBag;
    public Button btnRod;
    public Button btnFlashlight;

    // koupené upgrady
    private bool hasBagUpgrade = false;
    private bool hasRodUpgrade = false;
    private bool hasFlashlightUpgrade = false;

    private bool playerInRange = false;

    void Start()
    {
        shopPanel.SetActive(false);
        if (interactText != null) interactText.SetActive(false);
    }

    void Update()
    {
        // E = otevřít shop
        if (playerInRange && Input.GetKeyDown(KeyCode.E))
        {
            ToggleShop();
        }
    }

    void ToggleShop()
    {
        bool isShopOpen = !shopPanel.activeSelf;
        shopPanel.SetActive(isShopOpen);

        if (isShopOpen)
        {
            Time.timeScale = 0f;
            Cursor.lockState = CursorLockMode.None; 
            Cursor.visible = true;
        }
        else
        {
            Time.timeScale = 1f;
            Cursor.lockState = CursorLockMode.Locked; 
            Cursor.visible = false;
        }
    }

    public void BuyBagUpgrade()
    {
        if (hasBagUpgrade) return;

        if (inventory.currentMoney >= upgradeCost)
        {
            inventory.currentMoney -= upgradeCost;
            inventory.maxWeight = newBagCapacity;
            inventory.UpdateMoneyUI(); 
            
            hasBagUpgrade = true;
            DisableButton(btnBag);

            Debug.Log("Koupen batoh");
        }
    }

    public void BuyRodUpgrade()
    {
        if (hasRodUpgrade) return;

        if (inventory.currentMoney >= rodUpgradeCost)
        {
            inventory.currentMoney -= rodUpgradeCost;
            fishingController.rodMultiplier = 1.5f;
            inventory.UpdateMoneyUI();

            hasRodUpgrade = true;
            DisableButton(btnRod);

            Debug.Log("Koupen prut");
        }
    }

    public void BuyFlashlightUpgrade()
    {
        if (hasFlashlightUpgrade) return;

        if (inventory.currentMoney >= flashlightUpgradeCost && playerFlashlight != null)
        {
            inventory.currentMoney -= flashlightUpgradeCost;
            playerFlashlight.range = newFlashlightRange;
            playerFlashlight.intensity = newFlashlightIntensity;
            playerFlashlight.color = new Color(0.8f, 0.9f, 1f); 
            inventory.UpdateMoneyUI();

            hasFlashlightUpgrade = true;
            DisableButton(btnFlashlight);

            Debug.Log("Koupena baterka");
        }
    }

    public void SellAllFish()
    {
        if (inventory.backpack.Count == 0) return;

        float totalMoneyToGive = 0f;
        foreach (var caughtFish in inventory.backpack)
        {
            totalMoneyToGive += caughtFish.weight * pricePerKg; 
        }

        inventory.currentMoney += Mathf.Round(totalMoneyToGive); 
        inventory.backpack.Clear();
        inventory.currentWeight = 0f;

        inventory.UpdateUI();
        inventory.UpdateVisualInventory();
    }

    // vypne tlačítko a změní text
    private void DisableButton(Button btn)
    {
        if (btn != null)
        {
            btn.interactable = false;
            
            TextMeshProUGUI btnText = btn.GetComponentInChildren<TextMeshProUGUI>();
            if (btnText != null)
            {
                btnText.text = "VYPRODÁNO";
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            if (interactText != null) interactText.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            if (interactText != null) interactText.SetActive(false);

            shopPanel.SetActive(false);
            Time.timeScale = 1f;
        }
    }
}
