using UnityEngine;

public class WatchController : MonoBehaviour
{
    [Header("Nastavení Hodinek")]
    public Transform watchArm; // Odkaz na objekt "PlayerArm"
    
    // Tyhle pozice si nastavíme v editoru
    public Vector3 hiddenPosition = new Vector3(0.5f, -1f, 0.5f); 
    public Vector3 visiblePosition = new Vector3(0.3f, -0.2f, 0.6f); 
    
    public float moveSpeed = 8f; // Rychlost zvednutí ruky

    void Start()
    {
        // Na začátku dáme ruku dolů mimo zorné pole
        if (watchArm != null)
        {
            watchArm.localPosition = hiddenPosition;
        }
    }

    void Update()
    {
        if (watchArm == null) return;

        // Pokud hráč DRŽÍ klávesu T, ruka se zvedá
        if (Input.GetKey(KeyCode.T))
        {
            // Vector3.Lerp zajistí hezky plynulý přesun (ne teleport)
            watchArm.localPosition = Vector3.Lerp(watchArm.localPosition, visiblePosition, Time.deltaTime * moveSpeed);
        }
        else
        {
            // Pokud klávesu pustí, ruka jde plynule dolů
            watchArm.localPosition = Vector3.Lerp(watchArm.localPosition, hiddenPosition, Time.deltaTime * moveSpeed);
        }
    }
}