using UnityEngine;

public class BaitPickup : MonoBehaviour
{
    [Header("Nastavení")]
    public GameObject interactText; // Nápis "Zvedni návnadu [E]"
    private bool playerInRange = false;
    private InventoryManager inventory;

    void Start()
    {
        if (interactText != null) interactText.SetActive(false);
    }

    void Update()
    {
        // Pokud je hráč blízko a zmáčkne E
        if (playerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (inventory != null)
            {
                inventory.baitCount++; // Přidáme návnadu
                inventory.UpdateUI(); // Aktualizujeme text
                
                Debug.Log("Sebral jsi návnadu! Celkem máš: " + inventory.baitCount);
                
                // Zničíme předmět ve světě
                Destroy(gameObject); 
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            if (interactText != null) interactText.SetActive(true);
            
            // Najdeme inventář hráče
            inventory = other.GetComponent<InventoryManager>(); 
            if (inventory == null) inventory = FindObjectOfType<InventoryManager>();
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            if (interactText != null) interactText.SetActive(false);
            inventory = null;
        }
    }
}