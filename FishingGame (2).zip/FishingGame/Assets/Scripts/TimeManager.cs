using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class TimeManager : MonoBehaviour
{
    [Header("Time Settings")]
    public float timeSpeed = 0.05f; 
    public float currentHour = 8f; 
    public float endHour = 20f;    
 
    [Header("Lighting Settings")]
    public float sunsetStartHour = 17f; 
    public float nightStartHour = 20f;

    [Header("Skybox Art Direction")]
    [GradientUsage(true)] public Gradient skyColorGradient;    
    [GradientUsage(true)] public Gradient equatorColorGradient; 
    
    [Header("Sun Settings")]
    public AnimationCurve sunIntensityCurve; 
    [GradientUsage(true)] public Gradient sunColorGradient; 
    [Header("Ambient Light")]
    public Gradient ambientLightGradient; 

    private bool isDayActive = true;

    [Header("UI Reference")]
    public TMP_Text timeText;

    [Header("System References")]
    public Altar altar; 
    public Light sunLight; 

    [Header("Hororové Systémy")]
    public MonsterAI monster; 
    public InventoryManager inventory; 
    public float dailyQuota = 15f; 
    private bool isHuntingTime = false; 

    [Header("Hororové Zvuky")]
    public AudioSource nightAudioSource; 
    private bool isNightSoundPlaying = false; 

    void Start()
    {
        isDayActive = true;

        if (RenderSettings.skybox != null)
        {
            Material skyboxClone = new Material(RenderSettings.skybox);
            RenderSettings.skybox = skyboxClone;
        }
    }

    void Update()
    {
        if (!isDayActive) return;

        // Pokud ještě není 20:00, posouváme čas.
        // Jakmile padne 20:00, čas se zastaví (bude trvalá tma), ale HRA BĚŽÍ DÁL!
        if (currentHour < endHour)
        {
            currentHour += Time.deltaTime * timeSpeed;
        }
        else
        {
            currentHour = endHour; 
        }

        UpdateClockUI();
        UpdateLighting(); 

        // 1. HOROROVÝ ZVUK (Západ slunce)
        if (currentHour >= sunsetStartHour && !isNightSoundPlaying)
        {
            if (nightAudioSource != null) nightAudioSource.Play();
            isNightSoundPlaying = true;
        }
        else if (currentHour < sunsetStartHour && isNightSoundPlaying)
        {
            if (nightAudioSource != null) nightAudioSource.Stop();
            isNightSoundPlaying = false;
        }

        // 2. KONTROLA VE 20:00 (Konec dne)
        if (currentHour >= endHour)
        {
            // A) Hráč má dost ryb -> Vyhrál a přežil do dalšího dne
            if (inventory != null && inventory.currentWeight >= dailyQuota)
            {
                EndDaySuccess();
            }
            // B) Hráč nemá ryby a monstrum ještě neloví -> Vypustíme monstrum!
            else if (!isHuntingTime)
            {
                Debug.LogWarning("KVÓTA NESPLNĚNA! UTÍKEJ!");
                isHuntingTime = true;
                
                if (monster != null)
                {
                    monster.ChangeState(MonsterAI.MonsterState.Hunting);
                }
            }
        }
    }

    void UpdateClockUI()
    {
        if (timeText != null)
        {
            int hours = Mathf.FloorToInt(currentHour);
            int minutes = Mathf.FloorToInt((currentHour - hours) * 60f);
            timeText.text = string.Format("{0:00}:{1:00}", hours, minutes);

            if (currentHour >= 18f) timeText.color = Color.red;
            else timeText.color = Color.white;
        }
    }

    void UpdateLighting()
    {
        if (sunLight == null) return;

        float totalFishingHours = endHour - 8f;
        float progressThroughDay = (currentHour - 8f) / totalFishingHours;
        progressThroughDay = Mathf.Clamp01(progressThroughDay);

        float angle = progressThroughDay * 180f;
        sunLight.transform.localRotation = Quaternion.Euler(new Vector3(angle, -90f, 0f));

        RenderSettings.skybox.SetColor("_SkyTint", skyColorGradient.Evaluate(progressThroughDay));
        RenderSettings.skybox.SetColor("_GroundColor", equatorColorGradient.Evaluate(progressThroughDay));

        sunLight.intensity = sunIntensityCurve.Evaluate(progressThroughDay);
        sunLight.color = sunColorGradient.Evaluate(progressThroughDay);
        RenderSettings.ambientLight = ambientLightGradient.Evaluate(progressThroughDay);

        float darkness = 0f;
        if (currentHour >= sunsetStartHour)
        {
            darkness = (currentHour - sunsetStartHour) / (nightStartHour - sunsetStartHour);
            darkness = Mathf.Clamp01(darkness); 
        }

        RenderSettings.skybox.SetFloat("_Exposure", Mathf.Lerp(1f, 0.05f, darkness));
    }

    void EndDaySuccess()
    {
        Debug.Log("PŘEŽIL JSI! Entita tě nechá žít. Začíná další den...");
        if (altar != null)
        {
            altar.currentSacrifice = 0f;
            altar.dailyQuota += 5f; 
            altar.UpdateUI(); 
        }
        
        // Resetujeme inventář pro další den (Odevzdal jsi ryby)
        if (inventory != null)
        {
            inventory.backpack.Clear();
            inventory.currentWeight = 0f;
            inventory.UpdateUI();
            inventory.UpdateVisualInventory();
        }

        currentHour = 8f;
        isDayActive = true;
        isHuntingTime = false; 
    }

    // Tuto funkci zavolá samo Monstrum, až hráče dožene!
    public void TriggerGameOver()
    {
        Debug.Log("GAME OVER! Monstrum tě dostalo.");
    
        // Musíme vrátit čas na 1, jinak by se nová scéna "zasekla" na 0!
        Time.timeScale = 1f; 

        // Odemkneme kurzor, aby mohl hráč v nové scéně klikat na tlačítka
        Cursor.lockState = CursorLockMode.None; 
        Cursor.visible = true;

        // Načte scénu podle názvu
        SceneManager.LoadScene("GameOverScene");
    }      
}