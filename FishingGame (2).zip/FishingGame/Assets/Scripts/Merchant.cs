using UnityEngine;
using TMPro;

public class Merchant : MonoBehaviour
{
    [Header("UI Reference")]
    public TextMeshProUGUI merchantText;

    void Start()
    {
        if (merchantText != null) 
        {
            merchantText.text = "OBCHODNÍK\nZmáčkni E pro prodej";
            // Na začátku hry text rovnou skryjeme
            merchantText.gameObject.SetActive(false); 
        }
    }

    // NOVÉ: Zapne text, jakmile Hráč vstoupí do zelené zóny
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (merchantText != null) merchantText.gameObject.SetActive(true);
        }
    }

    // NOVÉ: Vypne text, jakmile Hráč ze zelené zóny odejde
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (merchantText != null) merchantText.gameObject.SetActive(false);
        }
    }

    // Zbytek zůstává stejný - samotný prodej
    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") )
        {
            InventoryManager inventory = other.GetComponent<InventoryManager>();
            
            
    }
    }    

    void SellAllFish(InventoryManager inventory)
    {
        float totalEarnings = 0f;

        foreach (var fish in inventory.backpack)
        {
            totalEarnings += fish.weight * fish.fishData.pricePerKg;
        }

        totalEarnings = Mathf.Round(totalEarnings * 100f) / 100f;
        inventory.currentMoney += totalEarnings;

        inventory.backpack.Clear();
        inventory.currentWeight = 0f;
        
        inventory.UpdateUI();
        inventory.UpdateVisualInventory();

        if (merchantText != null) 
        {
            merchantText.text = $"OBCHODNÍK\n<color=green>Prodáno za +{totalEarnings} $</color>";
            Invoke("ResetText", 2f); 
        }
    }

    void ResetText()
    {
        if (merchantText != null) merchantText.text = "OBCHODNÍK\nZmáčkni E pro prodej";
    }
}