using UnityEngine;

public class FlashlightController : MonoBehaviour
{
    [Header("Flashlight Settings")]
    public KeyCode toggleKey = KeyCode.F; 
    public Light flashlightLight;     

    private bool isOn = false; 

    void Start()
    {
        // Kontrola prirazeni svetla
        if (flashlightLight == null)
        {
            Debug.LogError("Chybí odkaz na 'Flashlight Light' na objektu Player!");
            return;
        }

        // Na začátku hry baterku vypneme
        flashlightLight.enabled = false;
        isOn = false;
    }

    void Update()
    {
        // Zkontrolujeme, zda hráč nezmáčkl klávesu F
        if (Input.GetKeyDown(toggleKey))
        {
            ToggleFlashlight();
        }
    }

    void ToggleFlashlight()
    {
        isOn = !isOn; // Obrátíme stav (Off -> On, On -> Off)
        flashlightLight.enabled = isOn; 
        
      
    }
}