using UnityEngine;

public class FishingHotspot : MonoBehaviour
{
    // Tento násobitel použijeme v dalším kroku, aby hráč vytáhl těžší rybu!
    public float weightBonusMultiplier = 1.5f; 
    

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Bobber"))
        {
            Bobber b = other.GetComponent<Bobber>();
            if (b != null) b.isInHotspot = true; // Zapne bonus
            Debug.Log("🔥 Bonus aktivován!");
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Bobber"))
        {
            Bobber b = other.GetComponent<Bobber>();
            if (b != null) b.isInHotspot = false; // Vypne bonus
        }
    }
}