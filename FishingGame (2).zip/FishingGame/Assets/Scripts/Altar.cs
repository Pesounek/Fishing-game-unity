using UnityEngine;
using TMPro;

public class Altar : MonoBehaviour
{
    [Header("Quota Settings (The Tithe)")]
    public float dailyQuota = 20f; 
    public float currentSacrifice = 0f; 

    [Header("UI Reference")]
    public TextMeshProUGUI altarText;

    private bool isPlayerInRange = false;

    void Start()
    {
        
        UpdateUI();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;
            UpdateUI(); // Pri vstupu napise jeste napis zmackni E
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;
            UpdateUI(); // pri odchodu zavoláme UpdateUI, aby se nápis "Zmáčkni E" smazal
        }
    }

    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && Input.GetKeyDown(KeyCode.E))
        {
            InventoryManager inventory = other.GetComponent<InventoryManager>();
            
            if (inventory != null && inventory.currentWeight > 0)
            {
                SacrificeFish(inventory);
            }
            else if (inventory != null && inventory.currentWeight <= 0)
            {
                Debug.Log("Nemáš žádné ryby k obětování!");
            }
        }
    }

    void SacrificeFish(InventoryManager inventory)
    {
        currentSacrifice += inventory.currentWeight;

        inventory.backpack.Clear();
        inventory.currentWeight = 0f;
        
        inventory.UpdateUI(); 
        inventory.UpdateVisualInventory(); 

        Debug.Log("Ryby úspěšně obětovány!");
        UpdateUI(); 
        CheckQuota();
    }

    public void UpdateUI()
    {
        if (altarText != null)
        {
            float roundedSacrifice = Mathf.Round(currentSacrifice * 100f) / 100f;
            string baseText = $"OLTÁŘ (Kvóta)\nObětováno: {roundedSacrifice} kg / {dailyQuota} kg";
            
            if (currentSacrifice >= dailyQuota)
            {
                baseText += "\n<color=green>KVÓTA SPLNĚNA!</color>";
            }
            
            // Tady se na konec textu přidá nápověda JEN TEHDY, když jsi uvnitř zóny
            if (isPlayerInRange)
            {
                baseText += "\n<size=80%>Zmáčkni E pro odevzdání ryb</size>";
            }

            altarText.text = baseText;
        }
    }

    void CheckQuota()
    {
        if (currentSacrifice >= dailyQuota)
        {
            Debug.Log("KVÓTA SPLNĚNA! Entita je uspokojena... pro dnešek.");
        }
    }
}