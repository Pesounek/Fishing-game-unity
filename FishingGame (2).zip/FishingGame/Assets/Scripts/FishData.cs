using UnityEngine;

// Prida polozku do add create
[CreateAssetMenu(fileName = "NewFish", menuName = "Fishing/Fish Data")]
public class FishData : ScriptableObject
{
    public string fishName; 
    public float minWeight; 
    public float maxWeight; 
    public float pricePerKg; 
    public Sprite fishIcon;
    [TextArea]
    public string description; 
}