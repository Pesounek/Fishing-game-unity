using UnityEngine;
using UnityEngine.UI; 
using TMPro; 

public class FishingController : MonoBehaviour
{
    [Header("Fishing Setup")]
    public GameObject bobberPrefab;
    public Transform castPoint;
    public LineRenderer lineRenderer;
    public FishData[] availableFish; 

    [Header("Casting Settings")]
    public float minForce = 5f;
    public float maxForce = 25f;
    public float chargeRate = 15f;
    public int linePoints = 30;
    public float timeBetweenPoints = 0.1f;

    [Header("Custom UI Elements")]
    public GameObject tensionBarUI; 
    public RectTransform greenZoneRect; 
    public RectTransform pointerRect; 
    public TextMeshProUGUI progressText; 

    [Header("Sweet Spot Settings")]
    public float tensionPullSpeed = 40f; 
    public float tensionDropSpeed = 40f; 
    public float progressSpeed = 15f; 
    public float progressDrainSpeed = 10f; 
    
    private float minSweetSpot; 
    private float maxSweetSpot; 

    private float currentForce;
    private bool isCharging = false;
    private GameObject currentBobber;

    private bool isReelingMatch = false; 
    private float currentTension = 50f; 
    private float catchProgress = 0f; 
    public InventoryManager inventory;
    private FishData hookedFish;
    private float hookedWeight;
    
    // Tady je tvůj modifikátor z obchodu!
    public float rodMultiplier = 1.0f;

    void Start()
    {
        // OPRAVA: Prut si sám najde tvůj inventář!
        if (inventory == null)
        {
            inventory = GetComponent<InventoryManager>();
        }

        if (lineRenderer != null) lineRenderer.enabled = false;
        if (tensionBarUI != null) tensionBarUI.SetActive(false); 
        if (progressText != null) progressText.gameObject.SetActive(false); 
    }

    void Update()
    {
        // Pokud je čas zastavený (otevřený obchod nebo Game Over), ignoruj klikání.
        if (Time.timeScale == 0) return;

        if (isReelingMatch) HandleReeling();
        else if (currentBobber == null) HandleCasting();
        else HandleFishing();
    }

    void HandleCasting()
    {
        if (Input.GetMouseButtonDown(0))
        {
            isCharging = true;
            currentForce = minForce;
            lineRenderer.enabled = true;
        }
        if (Input.GetMouseButton(0) && isCharging)
        {
            currentForce += chargeRate * Time.deltaTime;
            currentForce = Mathf.Clamp(currentForce, minForce, maxForce);
            DrawTrajectory();
        }
        if (Input.GetMouseButtonUp(0) && isCharging)
        {
            isCharging = false;
            lineRenderer.enabled = false;
            CastBobber();
        }
    }

    void HandleFishing()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Bobber bobberScript = currentBobber.GetComponent<Bobber>();
            if (bobberScript != null)
            {
                if (bobberScript.currentState == Bobber.BobberState.Flying || bobberScript.currentState == Bobber.BobberState.Finished)
                {
                    Destroy(currentBobber);
                    return;
                }

                if (bobberScript.TryHookFish()) StartReelingMatch(); 
                else Destroy(currentBobber);
            }
        }
    }

    void StartReelingMatch()
    {
        isReelingMatch = true;
        currentTension = 50f; 
        catchProgress = 15f; 
        
        // 1. Vyber ryby na zacatku boje
        if (availableFish != null && availableFish.Length > 0)
        {
            hookedFish = availableFish[Random.Range(0, availableFish.Length)];
        
            // --- SYSTÉM BONUSŮ A NÁVNAD ---
            float multiplier = 1f; // Základní násobitel
            
            // A) Bonus ze splávku (Hotspot)
            Bobber b = currentBobber.GetComponent<Bobber>();
            if (b != null && b.isInHotspot) 
            {
                multiplier += 1f; // Hotspot dává +1 k násobiteli
                Debug.Log("Chytáš v Hotspotu!");
            }

            // B) Bonus z návnady
            if (inventory != null && inventory.baitCount > 0)
            {
                inventory.baitCount--; // Odečtení návnady
                inventory.UpdateUI();  // Aktualizace textu
                
                multiplier += 1f; // Návnada dává další +1 k násobiteli
                Debug.Log("Ryba sežrala návnadu! Zbývá ti: " + inventory.baitCount);
            }

            // Výpočet váhy s celkovým multiplikátorem
            hookedWeight = Random.Range(hookedFish.minWeight, hookedFish.maxWeight) * multiplier;
            hookedWeight = Mathf.Round(hookedWeight * 100f) / 100f;
        }

        // 2. Výpočet velikosti zelené zóny s bonusem za lepší prut
        float baseZoneSize = 50f - (hookedWeight * 8f); 
        float zoneSize = baseZoneSize * rodMultiplier; 
        zoneSize = Mathf.Clamp(zoneSize, 10f, 75f); 

        // 3. Hodíme zónu na náhodné místo na liště
        float centerPoint = Random.Range(zoneSize / 2f, 100f - (zoneSize / 2f));
        minSweetSpot = centerPoint - (zoneSize / 2f);
        maxSweetSpot = centerPoint + (zoneSize / 2f);

        SetupGreenZoneVisuals(); 

        if (tensionBarUI != null) tensionBarUI.SetActive(true); 
        if (progressText != null) progressText.gameObject.SetActive(true);
    }

    void SetupGreenZoneVisuals()
    {
        if (greenZoneRect != null)
        {
            float minAnchor = minSweetSpot / 100f;
            float maxAnchor = maxSweetSpot / 100f;
            greenZoneRect.anchorMin = new Vector2(minAnchor, 0f);
            greenZoneRect.anchorMax = new Vector2(maxAnchor, 1f);
            greenZoneRect.offsetMin = Vector2.zero;
            greenZoneRect.offsetMax = Vector2.zero;
        }
    }

    void HandleReeling()
    {
        if (Input.GetMouseButton(0)) currentTension += tensionPullSpeed * Time.deltaTime;
        else currentTension -= tensionDropSpeed * Time.deltaTime;

        currentTension += Random.Range(-10f, 10f) * Time.deltaTime;
        currentTension = Mathf.Clamp(currentTension, 0, 100f);
        
        if (pointerRect != null)
        {
            float anchorX = currentTension / 100f;
            pointerRect.anchorMin = new Vector2(anchorX, 0.5f);
            pointerRect.anchorMax = new Vector2(anchorX, 0.5f);
            pointerRect.anchoredPosition = Vector2.zero; 
        }

        bool inSweetSpot = currentTension >= minSweetSpot && currentTension <= maxSweetSpot;

        if (inSweetSpot)
        {
            catchProgress += progressSpeed * Time.deltaTime; 
            if (progressText != null) { progressText.text = "Zdolávání: " + Mathf.RoundToInt(catchProgress) + "%"; progressText.color = Color.green; }
        }
        else
        {
            catchProgress -= progressDrainSpeed * Time.deltaTime; 
            if (progressText != null) { progressText.text = "Mimo zónu: " + Mathf.RoundToInt(catchProgress) + "%"; progressText.color = Color.red; }
        }

        catchProgress = Mathf.Clamp(catchProgress, 0, 100f);

        if (currentTension >= 100f) { Debug.Log("Vlasec praskl!"); EndReelingMatch(); return; }
        if (currentTension <= 0f) { Debug.Log("Ryba se vyvlíkla!"); EndReelingMatch(); return; }
        if (catchProgress >= 100f) { CatchFish(); EndReelingMatch(); } 
        else if (catchProgress <= 0f) { Debug.Log("Ryba utekla."); EndReelingMatch(); }
    }

    void CatchFish()
    {
        if (hookedFish != null)
        {
            InventoryManager inv = GetComponent<InventoryManager>();
            if (inv != null)
            {
                bool addedSuccessfully = inv.AddFish(hookedFish, hookedWeight);
                if (!addedSuccessfully) Debug.Log("Museli jsme rybu pustit, nemáme místo.");
            }
        }
    }

    void EndReelingMatch()
    {
        isReelingMatch = false;
        if (tensionBarUI != null) tensionBarUI.SetActive(false); 
        if (progressText != null) progressText.gameObject.SetActive(false);
        Destroy(currentBobber); 
    }

    void DrawTrajectory()
    {
        lineRenderer.positionCount = linePoints;
        Vector3 startPosition = castPoint.position;
        Vector3 startVelocity = (Camera.main.transform.forward + (Vector3.up * 0.5f)).normalized * currentForce;

        for (int i = 0; i < linePoints; i++)
        {
            float t = i * timeBetweenPoints;
            Vector3 point = startPosition + t * startVelocity;
            point.y = startPosition.y + startVelocity.y * t + (Physics.gravity.y / 2f) * t * t;
            lineRenderer.SetPosition(i, point);
        }
    }

    void CastBobber()
    {
        currentBobber = Instantiate(bobberPrefab, castPoint.position, castPoint.rotation);
        Rigidbody rb = currentBobber.GetComponent<Rigidbody>();
        CharacterController playerController = GetComponent<CharacterController>();
        Collider bobberCollider = currentBobber.GetComponent<Collider>();
        if (playerController != null && bobberCollider != null) Physics.IgnoreCollision(playerController, bobberCollider);
        if (rb != null) 
        {
            Vector3 throwDirection = (Camera.main.transform.forward + (Vector3.up * 0.5f)).normalized;
            rb.AddForce(throwDirection * currentForce, ForceMode.Impulse);
        }
    }
}