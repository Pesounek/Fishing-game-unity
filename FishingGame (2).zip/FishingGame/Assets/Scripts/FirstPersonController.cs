using UnityEngine;

public class FirstPersonController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float walkSpeed = 4f;
    public float sprintSpeed = 7f;
    public float gravity = -9.81f;
    public float jumpHeight = 1.5f;

    [Header("Camera Settings")]
    public Transform playerCamera;
    public float mouseSensitivity = 2f;

    [Header("Ground Detection")]
    public Transform groundCheck; 
    public float groundDistance = 0.4f; 
    public LayerMask groundMask; 

    private float xRotation = 0f;
    private CharacterController controller;
    private Vector3 velocity;
    private bool isGrounded;

    // Odkaz na systém staminy
    private StaminaManager staminaManager;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        staminaManager = GetComponent<StaminaManager>();
        
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        // 1. Detekce země
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f; 
        }

        // 2. Volání všech funkcí pohybu
        HandleLook();
        HandleMovement();
        HandleJump(); // <-- Tady je to tvoje skákání!
    }

    void HandleLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        playerCamera.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        transform.Rotate(Vector3.up * mouseX);
    }

    void HandleMovement()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        bool isMoving = Mathf.Abs(x) > 0 || Mathf.Abs(z) > 0;
        bool isSprinting = Input.GetKey(KeyCode.LeftShift) && isMoving && staminaManager.canSprint;

        if (staminaManager != null)
        {
            staminaManager.isSprinting = isSprinting;
        }

        float currentSpeed = isSprinting ? sprintSpeed : walkSpeed;

        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move * currentSpeed * Time.deltaTime);
    }

    void HandleJump()
    {
        // Skok se provede, pokud zmáčkneš mezerník, jsi na zemi 
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
          
            
                velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
            
        }

        // Gravitace tě neustále táhne dolů
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    void OnDrawGizmos()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundDistance);
        }
    }
}