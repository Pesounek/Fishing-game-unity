using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    [Header("UI")]
    public GameObject pauseMenuUI; // panel pauzy

    public static bool GameIsPaused = false;

    void Start()
    {
        // vypne menu a pustí čas
        if (pauseMenuUI != null) pauseMenuUI.SetActive(false);
        GameIsPaused = false;
        Time.timeScale = 1f;
    }

    void Update()
    {
        // ESC = pauza
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (Time.timeScale == 0f && !GameIsPaused) return;

            if (GameIsPaused)
                Resume();
            else
                Pause();
        }
    }

    public void Resume()
    {
        pauseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        GameIsPaused = false;

        // zamkne myš
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    public void MenuMain()
    {
        SceneManager.LoadScene(2);
    }

    void Pause()
    {
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        GameIsPaused = true;

        // odemkne myš
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void QuitGame()
    {
        Debug.Log("Vypínám hru...");
        Application.Quit();
    }
}