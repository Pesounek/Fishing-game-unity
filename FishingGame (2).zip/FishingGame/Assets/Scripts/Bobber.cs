using UnityEngine;

public class Bobber : MonoBehaviour
{
    public enum BobberState { Flying, InWater, Bite, Finished }
    public BobberState currentState = BobberState.Flying;

    [Header("Bite Settings")]
    public float minBiteTime = 2f; 
    public float maxBiteTime = 5f; 
    public float biteWindow = 1f;  

    private float timer = 0f;
    private float currentBiteWaitTime;
    private Renderer bobberRenderer;
    // Přidej tuto proměnnou do třídy Bobber
    public bool isInHotspot = false;

    void Start()
    {
        bobberRenderer = GetComponent<Renderer>();
    }

    void OnCollisionEnter(Collision collision)
    {
        // Pokud letíme a narazíme do čehokoliv, co se nejmenuje "Player"
        if (currentState == BobberState.Flying && collision.gameObject.name != "Player")
        {
            currentState = BobberState.InWater;
            currentBiteWaitTime = Random.Range(minBiteTime, maxBiteTime); 
            
            GetComponent<Rigidbody>().isKinematic = true; 
            
            // Kontrolní výpis do konzole
            Debug.Log("Splávek dopadl na: " + collision.gameObject.name + ". Čekám na záběr...");
        }
    }

    void Update()
    {
        if (currentState == BobberState.InWater)
        {
            timer += Time.deltaTime;
            if (timer >= currentBiteWaitTime)
            {
                StartBite();
            }
        }
        else if (currentState == BobberState.Bite)
        {
            timer -= Time.deltaTime; // Odpočet času na reakci hráče
            if (timer <= 0f)
            {
                FishEscaped();
            }
        }
    }

    void StartBite()
    {
        currentState = BobberState.Bite;
        timer = biteWindow;

        // Posunuti splavku dolu
        transform.position -= new Vector3(0, 0.05f, 0);
        
        if (bobberRenderer != null) 
        {
            bobberRenderer.material.color = Color.red;
        }
        
        Debug.Log("ZÁBĚR! Rychle klikni!");
    }

    void FishEscaped()
    {
        currentState = BobberState.Finished;
        
        if (bobberRenderer != null) 
        {
            bobberRenderer.material.color = Color.gray;
        }
        
     //spalvek zpatky nahoru
        transform.position += new Vector3(0, 0.05f, 0); 
        
        Debug.Log("Ryba utekla (Late click).");
    }

    // Tuto metodu zavolá hráčův prut, když klikne
    public bool TryHookFish()
    {
        if (currentState == BobberState.Bite)
        {
            currentState = BobberState.Finished;
            if (bobberRenderer != null) bobberRenderer.material.color = Color.green;
            Debug.Log("PERFEKTNÍ ZÁSEK! (Perfect click)");
            return true;
        }
        else if (currentState == BobberState.InWater)
        {
            currentState = BobberState.Finished;
            if (bobberRenderer != null) bobberRenderer.material.color = Color.gray;
            Debug.Log("Moc brzy! Ryba se vyplašila (Early click).");
            return false;
        }
        return false;
    }
}