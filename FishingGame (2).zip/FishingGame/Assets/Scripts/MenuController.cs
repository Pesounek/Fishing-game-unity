using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    
    public GameObject helpPanel;
    public void PlayAgain()
    {
        // Načte hlavní hru (Index 0 v Build Settings)
        SceneManager.LoadScene(0);
    }

    public void MainMenu()
    {
        SceneManager.LoadScene(2);
    }
    

    public void QuitGame()
        {
            Debug.Log("Ukončuji hru...");

            Application.Quit();
            
    }
    public void OpenHelp()
    {
        helpPanel.SetActive(true);
    }

    // Zavře help
    public void CloseHelp()
    {
        helpPanel.SetActive(false);
    }
}