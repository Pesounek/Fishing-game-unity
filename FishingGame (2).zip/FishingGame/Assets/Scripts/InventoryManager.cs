using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 
using TMPro; 

public class InventoryManager : MonoBehaviour
{
    [System.Serializable]
    public class CaughtFish
    {
        public FishData fishData; 
        public float weight;      
    }

    [Header("Inventory Settings")]
    public float maxWeight = 15f; 
    public float currentWeight = 0f; 
    public float currentMoney = 0f; 
    
    public List<CaughtFish> backpack = new List<CaughtFish>();

    [Header("UI Text References")]
    public TextMeshProUGUI inventoryText; 
    [Header("Návnady")]
    public int baitCount = 0; // Kolik návnad máš u sebe
    public TMPro.TextMeshProUGUI baitText; // UI text, který to ukazuje hráči
    [Header("Visual Inventory UI")] 
    public GameObject inventoryPanel; 
    public Transform fishGrid; 
    public GameObject fishSlotPrefab; 

    private bool isInventoryOpen = false;

    void Start()
    {
        if (inventoryPanel != null) inventoryPanel.SetActive(false); 
        UpdateUI();
    }

    // OPRAVA 2: Obchodník zavolá tuto funkci po nákupu. 
    // My jen řekneme inventáři, ať prostě znovu přepíše hlavní text pomocí UpdateUI()
    public void UpdateMoneyUI()
    {
        UpdateUI();
    }

    void Update()
    {
        // Otevírání batohu přes TAB
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            ToggleInventory();
        }
    }

    void ToggleInventory()
    {
        isInventoryOpen = !isInventoryOpen;
        if (inventoryPanel != null) inventoryPanel.SetActive(isInventoryOpen);
    }

    public bool AddFish(FishData fish, float weight)
    {
        // Upraveno na maxWeight
        if (currentWeight + weight > maxWeight)
        {
            Debug.Log("Batoh je plný!");
            return false; 
        }

        CaughtFish newFish = new CaughtFish { fishData = fish, weight = weight };
        backpack.Add(newFish);
        currentWeight += weight;

        UpdateUI(); 
        UpdateVisualInventory(); 
        return true;
    }

    public void UpdateVisualInventory()
    {
        if (fishGrid == null || fishSlotPrefab == null) return;

        foreach (Transform child in fishGrid)
        {
            Destroy(child.gameObject);
        }

        foreach (CaughtFish fish in backpack)
        {
            GameObject newSlot = Instantiate(fishSlotPrefab, fishGrid);
            
            Image slotImage = newSlot.GetComponent<Image>();
            TextMeshProUGUI slotText = newSlot.GetComponentInChildren<TextMeshProUGUI>();

            if (fish.fishData.fishIcon != null)
            {
                slotImage.sprite = fish.fishData.fishIcon;
            }

            if (slotText != null)
            {
                slotText.text = $"{Mathf.Round(fish.weight * 100f) / 100f} kg";
            }
        }
    }

    public void UpdateUI()
    {
        if (inventoryText != null)
        {
            float roundedWeight = Mathf.Round(currentWeight * 100f) / 100f;
            // Upraveno na maxWeight
            inventoryText.text = $"Batoh: {roundedWeight} kg / {maxWeight} kg\nPeníze: {currentMoney} $";
        }
        if (baitText != null)
        {
            baitText.text = "Návnady: " + baitCount;
        }
    }
}